import java.util.Scanner;
public class Q10{
    public static void main(String[] args) {
    System .out.println("What is your favourite musical group?");
    Scanner sc1 = new Scanner(System.in);
    String fg = sc1.nextLine();
    System.out.println("Your favourite musical group is" + fg + " .");
        }
}