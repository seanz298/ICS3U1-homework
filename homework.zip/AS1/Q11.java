import java.util.Scanner;
public class Q11{
    public static void main(String[] args) {
   System.out.println("How are you doing?");
  Scanner sc1 = new Scanner(System.in);
   String response = sc1.nextLine(); 
  System.out.println("Oh, how interesting. Tell me more!");
  String moreInfo = sc1.nextLine();
  System.out.println("Thanks for sharing!");
 }
}