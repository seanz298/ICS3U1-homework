import java.util.Scanner;
public class Q12{
    public static void main(String[] args) {
      System.out.println("What is your favourit movie");
        Scanner sc1 = new Scanner(System.in);
      String as1 = sc1.nextLine();
       System.out.println("Your favourite movie is " + as1);
        }
}