import java.util.Scanner;
public class Q13{
    public static void main(String[] args) {
          System.out.println("Which country are you in");
        Scanner sc1 = new Scanner(System.in);
      String as1 = sc1.nextLine();
      System.out.println("Which city are you in");
      String as2 = sc1.nextLine();
        System.out.println("You are at " + as1 +" " + as2);
    }
}