import java.util.Scanner;
public class Q14{
    public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
System.out.println("What is your favorite animal?");
  String am = scanner.nextLine();
     System.out.println("You like " + am);
    }
}