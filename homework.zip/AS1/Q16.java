import java.util.Scanner;
public class Q16{
    public static void main(String[] args) {
      Scanner scanner = new Scanner(System.in);
      System.out.println("What is your dream job?");
      String job = scanner.nextLine();
        System.out.println("Why do you want that job? ");
          String reason = scanner.nextLine();
           System.out.println("Your favourate job is " + job + " because " + reason);
    }
}