public class Q9 {
public static void main(String[] args) {
int number = 123456789;
System.out.println(number);

     }
}