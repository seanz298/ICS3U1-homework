/**
Q4.java
	Description:  ascII art
	Name: Sean
	Date Created: 2024/11/1
	Date last modified: 2024/11/1
*/
 public class Q4 {
    public static void main(String[] args) {
      String art = "         ,   ,   ,\n" +
                "        |\\  |\\  |\\\n" +
                "        | \\ | \\ | \\\n" +
                "        |  \\|  \\|  \\\n" +
                "        |   |   |   |\n" +
                "        |   |   |   |\n" +
                "        |   |   |   |\n" +
                "        |   |   |   |\n" +
                "      __|___|___|___|__\n" +
                "     |               |\n" +
                "     |    HAPPY     |\n" +
                "     |   BIRTHDAY!  |\n" +
                "     |_______________|\n";
      System.out.println(art);
    }
 }